# Punto 1 - Arquitectura Monolítica

Este proyecto contiene una implementación simple en Node.js donde toda la lógica está en un solo archivo (`app.js`).

## Características

- Agrega productos (`POST /agregar`)
- Lista productos (`GET /listar`)

## ¿Por qué es monolítico?

Toda la lógica de presentación, negocio y datos está en un único archivo, sin separación de responsabilidades.

## Desventajas

- Difícil de mantener y escalar.
- No se puede dividir el desarrollo fácilmente.
- Poca reutilización de código.