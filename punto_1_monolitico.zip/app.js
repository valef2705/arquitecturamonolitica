const express = require('express');
const app = express();
app.use(express.json());

// Lista en memoria
const productos = [];

// Agregar producto
app.post('/agregar', (req, res) => {
    const producto = {
        id: productos.length + 1,
        nombre: req.body.nombre,
        precio: req.body.precio
    };
    productos.push(producto);
    res.status(201).json({ mensaje: 'Producto agregado', producto });
});

// Listar productos
app.get('/listar', (req, res) => {
    res.json(productos);
});

// Servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

/*
Esta implementación es monolítica porque toda la lógica de presentación, negocio y datos está en un solo archivo.
Desventajas:
- Difícil de mantener cuando crece.
- No se puede dividir el trabajo fácilmente.
- Poco reutilizable y escalable.
*/